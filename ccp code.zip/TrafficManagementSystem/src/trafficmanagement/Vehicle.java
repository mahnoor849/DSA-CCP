package trafficmanagement;


public class Vehicle implements Comparable<Vehicle> {
    public String id;
    public boolean isEmergency;
    public long arrivalTime;

    public Vehicle(String id, boolean isEmergency) {
        this.id = id;
        this.isEmergency = isEmergency;
        this.arrivalTime = System.currentTimeMillis();
    }

    @Override
    public int compareTo(Vehicle v) {
        return Boolean.compare(v.isEmergency, this.isEmergency);
    }
}
