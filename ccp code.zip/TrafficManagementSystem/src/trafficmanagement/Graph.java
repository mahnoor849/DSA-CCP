
	package trafficmanagement;

	import java.util.*;

	public class Graph {
	    public Map<String, List<Road>> adjList = new HashMap<>();

	    public void addEdge(String from, String to, int time) {
	        adjList.putIfAbsent(from, new ArrayList<>());
	        adjList.get(from).add(new Road(from, to, time));
	    }

	    public List<Road> getNeighbors(String node) {
	        return adjList.getOrDefault(node, new ArrayList<>());
	    }

	    public Map<String, Integer> dijkstra(String start) {
	        Map<String, Integer> dist = new HashMap<>();
	        PriorityQueue<Road> pq = new PriorityQueue<>(Comparator.comparingInt(r -> r.travelTime));

	        for (String node : adjList.keySet()) dist.put(node, Integer.MAX_VALUE);
	        dist.put(start, 0);
	        pq.add(new Road(start, start, 0));

	        while (!pq.isEmpty()) {
	            Road current = pq.poll();
	            for (Road neighbor : getNeighbors(current.to)) {
	                int newDist = dist.get(current.to) + neighbor.travelTime;
	                if (newDist < dist.get(neighbor.to)) {
	                    dist.put(neighbor.to, newDist);
	                    pq.add(new Road(neighbor.from, neighbor.to, newDist));
	                }
	            }
	        }
	        return dist;
	    }

	    public String getEdgeTrafficStats() {
	        StringBuilder sb = new StringBuilder("🚗 Road Traffic:\n");
	        for (String node : adjList.keySet()) {
	            for (Road r : adjList.get(node)) {
	                sb.append(r.from).append(" ➝ ").append(r.to)
	                  .append(" | Vehicles: ").append(r.vehicleCount).append("\n");
	            }
	        }
	        return sb.toString();
	    }
	}
