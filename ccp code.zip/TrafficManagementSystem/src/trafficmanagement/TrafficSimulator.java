package trafficmanagement;

import java.util.*;

public class TrafficSimulator {
    public Graph cityGraph = new Graph();
    public Map<String, Intersection> intersections = new HashMap<>();
	public int totalCleared;
	public int emergencyCleared;

    public void initialize() {
        for (int i = 1; i <= 50; i++) {
            String name = "I" + i;
            intersections.put(name, new Intersection(name));
        }
        for (int i = 1; i < 50; i++) {
            cityGraph.addEdge("I" + i, "I" + (i + 1), new Random().nextInt(5) + 1);
        }
        for (int i = 1; i <= 45; i += 5) {
            cityGraph.addEdge("I" + i, "I" + (i + 5), new Random().nextInt(5) + 2);
        }
    }

    public void addVehicle(String intersection, Vehicle v) {
        Intersection inter = intersections.get(intersection);
        if (inter != null) inter.addVehicle(v);
    }

    public void addInitialVehicles(int count) {
        Random rand = new Random();
        List<String> nodes = new ArrayList<>(intersections.keySet());
        for (int i = 1; i <= count; i++) {
            String id = "V" + i;
            boolean isEmergency = rand.nextInt(10) < 2;
            String randomNode = nodes.get(rand.nextInt(nodes.size()));
            addVehicle(randomNode, new Vehicle(id, isEmergency));
        }
    }

    public void runSimulationStep() {
        for (Intersection i : intersections.values()) {
            int totalQueue = i.normalQueue.size() + i.priorityQueue.size();
            i.trafficLight.adjustTiming(totalQueue);
            Vehicle processed = i.processVehicle();
            if (processed != null) {
                i.addToProcessed(processed);
            }
        }
    }

    public String getGraphSummary() {
        StringBuilder sb = new StringBuilder("\uD83D\uDCCC Road Connections:\n");
        for (String node : cityGraph.adjList.keySet()) {
            for (Road r : cityGraph.getNeighbors(node)) {
                sb.append("  ").append(r.from).append(" \u2794 ").append(r.to)
                  .append(" (").append(r.travelTime).append(" mins)\n");
            }
        }
        return sb.toString();
    }

	public String getTotalCleared() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getEmergencyCleared() {
		// TODO Auto-generated method stub
		return null;
	}
}
